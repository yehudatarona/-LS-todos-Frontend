import React, { Component } from "react";
import { doApiGet } from "../services/apiService";
import{Link, NavLink} from "react-router-dom"

class VipSingle extends Component {
    state = { vip: {} };
    componentDidMount() {
        let vipId = this.props.match.params.id;
        let url = "https://forbes400.herokuapp.com/api/forbes400/?limit=10"
        doApiGet(url)
            .then(data => {
                console.log("vipSingle", data);
                let vipData = data.filter(item => {
                    return (item.rank == vipId);
                });
                this.setState({ vip: vipData[0] });
            });

    }
    render() {
        let vip = this.state.vip
        return (
            <div className= "container-fluid">
                <div className = "container d-flex justify-content-center" >
                    {(vip.person) ?
                        (<div className = "col-lg-6 border p-3">
                            <h2>Info about: {vip.person.name}</h2>
                            <img src={vip.person.squareImage} />
                            <p>{vip.bios[0]}</p>
                    <div>Money: $ {vip.archivedWorth / 1000} B</div>
                            <Link to="/">Back to lis</Link>
                        </div>
                        ) : "Loading..."
                    }
                </div>
            </div>
        )
    }
}

export default VipSingle
    ;