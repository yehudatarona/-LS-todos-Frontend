import React,{Component} from "react";
import "../css_comps/games_header.css"

class Header extends Component{
  render(){
    return(
      <header className="container-fluid d-flex align-items-center">
        <div className="container text-center">
        <h1 className="display-2">Vips List</h1>
        </div>
      </header>
    
    )
  }
}

export default Header;
