
import React, { Component } from "react";
import{Link, NavLink} from "react-router-dom"

class VipItem extends Component {
  render() {
    let item = this.props.item;
    return (
      <div className="col-lg-6 border p-2">
        <img src={"https://"+item.person.squareImage} className="w-25 float-left mr-2" />
        <h2>{item.person.name}</h2>
        <div>Company: {item.source}</div>
        <Link className = "btn btn-info" to ={"person/"+item.rank}>More info </Link>
      </div>

    )
  }
}

export default VipItem;
