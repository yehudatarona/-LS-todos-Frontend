import React,{Component} from "react";
import Header from "./header";
import Nav from "./nav";
import Main from "./main";
import { BrowserRouter as Router, Switch, Route} from "react-router-dom";
import VipSingle from "./vipSingle";

class Appvips extends Component{
  render(){
    return(
      <Router>
      <div>
        <Header/>
        <Nav/>
        <Switch>
          <Route exact path ="/" component ={Main}/>
          <Route exact path ="/person/:id" component ={VipSingle}/>
        </Switch>
        {/* <Main/> */}
      </div>

      </Router>
    
    )
  }
}

export default Appvips;