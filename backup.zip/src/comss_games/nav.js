import React,{Component} from "react";

class Nav extends Component{
  render(){
    return(
      <nav className="container-fluid bg-dark text-white">
        <div className="container">
        Nav work
        </div>
      </nav>
    
    )
  }
}

export default Nav;