import React, { Component } from "react";
import { doApiGet } from "../services/apiService";
import VipItem from "./vipItem";


class Main extends Component {
  state = { vip_ar: [] }

  componentDidMount() {
    let url = "https://forbes400.herokuapp.com/api/forbes400/?limit=10"
    doApiGet(url)
      .then(data => {
        console.log(data)
        this.setState({ vip_ar: data })
      })
  }

  render() {
    return (
      <div className="container-fluid">
        <div className="container">
          <div className="row">
            {this.state.vip_ar.map(item => {
              return (
                <VipItem key={item.rank} item={item}  />
              )
            })}
          </div>
        </div>
      </div>

    )
  }
}

export default Main;


