export const doApiGet = async(_url) => {
  let resp = await fetch(_url);
  let data = await resp.json();
  return data;
}