import React from 'react';
import logo from './logo.svg';
import './App.css';
import Appvips from './comss_games/appVips';


function App() {
  return (
    <div className="App">
     <Appvips/>
    </div>
  );
}

export default App;
